<!DOCTYPE html>
<head>

</head>
<html>
	<body>
		<div id="footer-block">
			<p>Developed by the friendly folks at <a href="http://ets.educ.ubc.ca" target="_blank">Educational Technology Support</a>, Faculty of Education, UBC. </p>
		</div>
	</body>
</html>