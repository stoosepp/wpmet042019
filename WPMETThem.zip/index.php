<!DOCTYPE html>
<html style="margin-top:0px !important;">
	<head>
		<link rel="stylesheet" type="text/css" href="<?php bloginfo("template_directory"); ?>/style.css" />
	    <title><?php echo get_bloginfo( 'name' ); ?></title>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		    <script src="<?php echo plugins_url();?>/facetwp/assets/js/dist/front.min.js"></script>-->
	   
	</head>
	<body>
<!--
		<!--HEADER-->
		<?php get_header(); ?>
		
		<!--SEARCH AND FILTER-->
		
				
		<!--FOOTER-->
		<?php get_footer(); ?>

	</body>
</html>